
public class Ch7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//R7.2
		/* 0000000000
		 * 0123456789
		 * 0246802468
		 * 0369258147
		 * 0482604826
		 * 0505050505
		 * 0628406284
		 * 0741852963
		 * 0864208642
		 * 0987654321
		 */
		
		//R7.4
		/* int s = 0;
		 * for(int i = 1; i <= 10; i++)
		 * s = s + i
		 * 
		 * int s = 0
		 * while(int i = 1; i<=10){
		 * i++;
		 * s += i
		 * }
		 */
		
		//R7.5
		/* int n = 1;
		 * double x = 0;
		 * double s;
		 * while(s > 0){
		 * s = 1 / (n * n);
		 * x += x
		 * n++
		 * }
		 * 
		 */
		
		//PE 7.11
		/*
		 * int x;
		 * while(int z = 2; z <= x){
		 * 		if(i > 2)
		 * 		System.out.println
		 * 		while(int i = 1; i < 10){
		 * 			if(z % i = 0){
		 * 			y++
		 * 			}
		 * 		i++
		 * 		}
		 * 	z++
		 * }
		 * 
		 */
	}

}
