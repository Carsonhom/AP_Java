
public class sodatester {
	
	public static void main(String[] args) {
		
		SodaCan s1 = new SodaCan(4.83, 1.07);
		System.out.println("The surface area is " + s1.getSurfaceArea());
		System.out.println("The vomlume is " + s1.getVolume());
		
		
			
	}

}
