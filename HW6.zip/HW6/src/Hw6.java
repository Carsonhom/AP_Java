
public class Hw6 {
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//R6.1
		/* a. if quarters < 0 it will return an error
		 * b. x + 1 will never be greater
		 * c. needs to be x==1 and x==2
		 * d. x == 0
		 * e. 1 <= x && x <= 10
		 * f. Becomes an && statement
		 * g. input.equalIgnoreCase("NO")
		 * h. can't not equal a null 
		 * i. There is no else statement
		 * 
		 */
		
		//R6.5
		/* a. Tom
		 * b. Tom
		 * c. Churchill
		 * d. carburetor
		 * e. Harry
		 * f. C++
		 * g. Tom
		 * h. Car
		 * i. bar
		 * j. 101
		 * k. 1.01
		 */
		
		//R6.6
		/* P	Q	R		(P && Q) || !R		!(P && (Q || !R))
		 * f	f	f		T					T
		 * f	f	T		f					T
		 * T	f	f		T					f
		 * f	T	f		T					T
		 * T	T	f		T					f
		 * T	f	T		f					T
		 * 
		 */
		
		//R6.13
		/*
		 * == compares 2 references to see if they refer to the same object
		 * equals() compares the values of objects
		 */
		
		//PE6.4
		
		
		String s1 = "church";
		String s2 = "Churchill";
		
		System.out.println(s1.compareTo(s2));
		
		
		

	}

}
