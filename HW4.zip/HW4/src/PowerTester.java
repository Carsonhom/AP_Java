
public class PowerTester {
	
	public static void main(String[] args) {
		PowerGenerator g1 = new PowerGenerator(10);
		System.out.println(10);
		System.out.println(g1.nextPower());
		System.out.println(g1.nextPower());
		System.out.println(g1.nextPower());
		System.out.println(g1.nextPower());
		System.out.println(g1.nextPower());
		System.out.println(g1.nextPower());
		System.out.println(g1.nextPower());
		System.out.println(g1.nextPower());
		System.out.println(g1.nextPower());
		System.out.println(g1.nextPower());
		
	}
	

}
