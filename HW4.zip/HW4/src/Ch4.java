import java.awt.*;
public class Ch4 {

	public static void main(String[] args) {
		//R 4.1
		
		//double s = (s + (v * t) + (1/2 *(g * Math.pow(t, 2))));
		
		//double G = ((4 * Math.pow(Math.PI, 2)) * ((Math.pow(a, 3)) / (Math.pow(P, 2)) * (m1 + m2)));
		
		//double FV = PV * Math.pow((1 + (INT/100)), 2);
		
		//double c = Math.sqrt(Math.pow(a, 2) + Math.pow(b, 2) - (2 * a * b * Math.cos(y)));
		
		//R 4.11
		
		//double x = 123;
		
		//String y = "Hello";
		
		//a. Integer.parseInt("" + x) true
		
		//"" + Integer.parseInt(y); false
		
		//c. s.substring(0, s.length()) false
		
		//R 4.16
		
		
		
		//PE 5.6
		
		
		
		
		
		
		
	}
	
	
	
		
	
}
