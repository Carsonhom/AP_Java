
public interface CommonTraits {
	String taunt();
	String weapon();
	int run();
	String defenses();
	String vehicles();
	String weakness();
	
	

}
